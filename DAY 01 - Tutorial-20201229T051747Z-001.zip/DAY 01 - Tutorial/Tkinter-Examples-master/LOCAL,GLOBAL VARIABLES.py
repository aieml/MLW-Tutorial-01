var=10

def func1():

    global var
    print(var)


func1()
